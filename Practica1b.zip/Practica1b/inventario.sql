-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-02-2021 a las 22:52:20
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `moviles`
--

CREATE TABLE `moviles` (
  `ID` int(5) NOT NULL,
  `NOMBRE` varchar(30) NOT NULL,
  `MARCA` varchar(30) NOT NULL,
  `MODELO` varchar(30) NOT NULL,
  `RAM` varchar(30) NOT NULL,
  `PROCESADOR` varchar(30) NOT NULL,
  `FECHA_REG` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `moviles`
--

INSERT INTO `moviles` (`ID`, `NOMBRE`, `MARCA`, `MODELO`, `RAM`, `PROCESADOR`, `FECHA_REG`) VALUES
(44, 'prueba1', 'huawei', 'p20', '4', 'kirin', '2021-02-25'),
(45, 'prueba2', 'xiaomi', 'note 10', '12', 'snapdragon', '2021-02-25'),
(46, 'prueba3', 'xiaomi', 'note 11', '4', 'kirin', '2021-02-25'),
(47, 'prueba4', 'xiaomi', 'note 10', '4', 'snapdragon', '2021-02-25'),
(48, 'prueba4', 'xiaomi', 'gsrrg', '12', 'snapdragon', '2021-02-25'),
(49, 'prueba4', 'xiaomi', 'note 10', '4', 'snapdragon', '2021-02-25'),
(50, 'prueba4', 'xiaomi', 'note 11', '6', 'snapdragon', '2021-02-25'),
(51, 'prueba4', 'xiaomi', 'note 10', '6', 'snapdragon', '2021-02-25'),
(52, 'prueba4', 'xiaomi', 'note 10', '7', 'kirin', '2021-02-25'),
(53, 'prueba4', 'xiaomi', 'p20', '6', 'kirin', '2021-02-25'),
(54, 'prueba4', 'xiaomi', 'note 10', '6', 'snapdragon', '2021-02-25'),
(56, 'editado', 'actualizada', 'note 10', '12', 'snapdragon', '2021-02-25'),
(57, 'prueba', 'xiaomi', 'note 10', '4', 'kirin', '2021-02-25'),
(58, 'prueba4', 'xiaomi', 'p20', '6', 'wefe', '2021-02-25');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `moviles`
--
ALTER TABLE `moviles`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `moviles`
--
ALTER TABLE `moviles`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
