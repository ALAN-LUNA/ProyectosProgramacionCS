<?php
require "app/Models/conexion.php";
require "app/Models/registrar.php";
require "app/Models/editar.php";
require "app/Models/borrar.php";
require "app/Models/comparacion.php";
require "app/Models/filtrarSem.php";
require "app/Models/Modelos.php";

use inventario\Modelos;
use inventario\filtroS;
use inventario\borrar;
use inventario\actualizar;
use inventario\registrar;
use inventario\comRam;

class dispositivosController
{

    function inventario()
    {
        $modelos = new Modelos();
        $modelos->mayores();
        require "app/Views/inventario.php";
    }
    function registrar()
    {
        $reg = new registrar();
        $reg->nombre = $_POST["nombre"];
        $reg->marca = $_POST["marca"];
        $reg->modelo = $_POST["modelo"];
        $reg->ram = $_POST["ram"];
        $reg->procesador = $_POST["procesador"];
        $reg->registrar();
    }
    function actualizar()
    {
        $act = new actualizar();
        $act->nombre = $_POST["nombre"];
        $act->marca = $_POST["marca"];
        $act->modelo = $_POST["modelo"];
        $act->ram = $_POST["ram"];
        $act->procesador = $_POST["procesador"];
        $act->obtener($_POST["id"]);
    }
    function borrar()
    {
        $del = new borrar();
        $del->eliminarRegistro($_POST["id"]);
    }
    function comparacion()
    {
        $ram = new comRam();
        $ram->compram($_POST["id1"], $_POST["id2"]);
    }
    function filtroxSemanas()
    {
        require "app/Views/registrosSemana.php";
        $filtro = new filtroS();
        $filtro->semanaRegistro($_POST["semana"]);
    }
    function avisoModelos()
    {
        $modelos = new Modelos();
        $modelos->mayores();
    }
}
