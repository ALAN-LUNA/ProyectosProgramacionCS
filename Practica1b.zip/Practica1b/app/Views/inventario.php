<?php

$host = "localhost";
$user = "root";
$contraseña = "";
$base = "inventario";
$conexion = mysqli_connect($host, $user, $contraseña, $base);

$consulta = "SELECT * FROM moviles";
$resultado = mysqli_query($conexion, $consulta);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inventario</title>
    <!--bootstrap-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

<body>
    <nav class="navbar navbar-dark bg-dark">
        <div class="container">
            <a href="http://localhost/Practica1b/index.php?controller=dispositivos&action=inventario" class="navbar-brand">Inventario de Dispositivos</a>
        </div>
    </nav>

    <div class="container p-2">
        <div class="col-md-12">
            <div class="card card body">
                <h5>Registrar nuevo</h5>
                <form method="POST" action="http://localhost/Practica1b/index.php?controller=dispositivos&action=registrar">
                    <table>
                        <tr>
                            <th>Nombre</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>RAM</th>
                            <th>Procesador</th>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="nombre" class="centrar-texto" placeholder="Nombre" required>
                            <td>
                                <input type="text" name="marca" class="centrar-texto" placeholder="Marca" required>
                            </td>
                            <td>
                                <input type="text" name="modelo" class="centrar-texto" placeholder="Modelo" required>
                            </td>
                            <td>
                                <input type="text" name="ram" class="centrar-texto" placeholder="Ram" required>
                            </td>
                            <td>
                                <input type="text" name="procesador" class="centrar-texto" placeholder="Procesador" required>
                            </td>
                            <td>
                                <input type="submit" value="Registar Nuevo" class="btn btn-success">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

    <div class="container p-2">
        <div class="col-md-12">
            <div class="card card_body">
                <h5>Actualizar movil</h5>
                <form class="formulario" method="POST" action="http://localhost/Practica1b/index.php?controller=dispositivos&action=actualizar">

                    <table>
                        <tr>
                            <th>Ingrese el ID</th>
                            <th>Nombre</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>RAM</th>
                            <th>Procesador</th>
                        </tr>
                        <tr>
                            <td>
                                <input type="number" size="5" name="id">
                            </td>
                            <td>
                                <input type="text" name="nombre" class="centrar-texto" placeholder="Nombre" required>
                            <td>
                                <input type="text" name="marca" class="centrar-texto" placeholder="Marca" required>
                            </td>
                            <td>
                                <input type="text" name="modelo" class="centrar-texto" placeholder="Modelo" required>
                            </td>
                            <td>
                                <input type="text" name="ram" class="centrar-texto" placeholder="Ram" required>
                            </td>
                            <td>
                                <input type="text" name="procesador" class="centrar-texto" placeholder="Procesador" required>
                            </td>
                        </tr>
                    </table>
                    <br>
                    <input type="submit" value="Editar" class="btn btn-success">
                </form>
            </div>
        </div>
    </div>
    <div class="container p-4">
        <table class="table">
            <tr>
                <th>ID</th>
                <th>NOMBRE</th>
                <th>MARCA</th>
                <th>MODELO</th>
                <th>RAM</th>
                <th>PROCESADOR</th>
                <th>FECHA DE REGISTRO</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($resultado)) { ?>
                <tr>
                    <td>
                        <?php echo $row["ID"]; ?>

                    </td>
                    <td>
                        <?php echo $row["NOMBRE"]; ?>

                    <td>
                        <?php echo $row["MARCA"]; ?>
                    </td>
                    <td>
                        <?php echo $row["MODELO"]; ?>

                    </td>
                    <td>
                        <?php echo $row["RAM"]; ?>
                    </td>
                    <td>
                        <?php echo $row["PROCESADOR"]; ?>
                    </td>
                    <td>
                        <?php echo $row["FECHA_REG"]; ?>
                    </td>

                </tr>

            <?php
            }
            ?>
        </table>
    </div>

    <div class="container p-2">
        <div class="col-md-3">
            <div class="card card-body">
                <h5>Eliminar movil</h5>
                <form method="POST" action="http://localhost/Practica1b/index.php?controller=dispositivos&action=borrar">
                    <h5>Ingrese ID<h5>
                            <input type="number" size="3" name="id">
                            <br>
                            <br>
                            <input type="submit" value="Borrar" class="btn btn-success">
                </form>
            </div>
        </div>
    </div>

    <h5 style="text-align: center">Esta Marca tiene mas de 10 modelos: <?php if (isset($_SESSION["masmodelos"])) echo $_SESSION["masmodelos"]; ?></h5>

    <div class="container p-2">
        <div class="col-md-10">
            <div class="card card-body">
                <h5>Comparacion entre moviles de memoria RAM</h5>
                <br>
                <form action="http://localhost/Practica1b/index.php?controller=dispositivos&action=comparacion" method="POST">

                    <h5>Ingrese el ID de un movil </h5>
                    <input type="number" size="1" name="id1">
                    <br>
                    <br>
                    <h5>Ingrese el ID de otro movil</h5>
                    <input type="number" size="1" name="id2">
                    <br>
                    <br>
                    <input type="submit" value="Comparar" class="btn btn-success">
                </form>
                <center>
                    <label>Dispositivo con mas Ram: <?php if (isset($_SESSION["mayor"])) echo $_SESSION["mayor"]; ?></label>
                </center>
            </div>
        </div>
    </div>

    <div class="container p-2">
        <form method="POST" action="http://localhost/Practica1b/index.php?controller=dispositivos&action=filtroxsemanas">
            <h3>Informe por Semanas</h3>
            <input type="date" value="2021-02-01" name="semana">
            <br>
            <br>
            <input type="submit" class="btn btn-success" value="Ver tabla de registros x semana">
        </form>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
</body>

</html>