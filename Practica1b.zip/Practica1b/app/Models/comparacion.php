<?php

namespace inventario;

class comRam
{

    public function compram($id1, $id2)
    {
        $conexion = new conexion();
        $consulta = "SELECT * FROM moviles WHERE ID = $id1";
        $resultado = mysqli_query($conexion->conn, $consulta);
        $datos = mysqli_fetch_object($resultado);
        $RAM1 = $datos->RAM;
        $_SESSION["nombre1"] = $datos->NOMBRE;
        
        $consulta = "SELECT * FROM moviles WHERE ID = $id2";
        $resultado = mysqli_query($conexion->conn, $consulta);
        $datos = mysqli_fetch_object($resultado);
        $RAM2 = $datos->RAM;
        $_SESSION["nombre2"] = $datos->NOMBRE;

        if ($RAM1 > $RAM2) {

            $_SESSION["mayor"] = $_SESSION["nombre1"];
            
            header('location: http://localhost/Practica1b/index.php?controller=dispositivos&action=inventario');

        } else {

            $_SESSION["mayor"] = $_SESSION["nombre2"];

            header('location: http://localhost/Practica1b/index.php?controller=dispositivos&action=inventario');

        }
    }
}
