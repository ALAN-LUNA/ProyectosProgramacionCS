<?php

namespace inventario;

class conexion{

    public $conn;
    public function __construct()
    {
        $host="localhost";
        $user="root";
        $contraseña="";
        $bd="inventario";
        $this->conn = mysqli_connect($host, $user, $contraseña, $bd);
    }

}
?>