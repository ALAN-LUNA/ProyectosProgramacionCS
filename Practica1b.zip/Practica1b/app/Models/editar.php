<?php

namespace inventario;

class actualizar
{

    public $nombre;
    public $marca;
    public $modelo;
    public $ram;
    public $procesador;

    public function obtener($id)
    {

        $conexion = new conexion();
        $consulta = mysqli_prepare($conexion->conn, "UPDATE moviles SET NOMBRE = ?,MARCA = ?,MODELO = ?,RAM = ?,PROCESADOR = ? WHERE ID = ?");
        $consulta->bind_param("ssssss", $this->nombre, $this->marca, $this->modelo, $this->ram, $this->procesador, $id);
        $consulta->execute();

       header('Location: app/Views/inventario.php');
    }
}
?>