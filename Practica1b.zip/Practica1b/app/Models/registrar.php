<?php

namespace inventario;

class registrar
{
    public $nombre;
    public $marca;
    public $modelo;
    public $ram;
    public $procesador;

    public function registrar()
    {
        $conexion = new conexion();
        $consulta = mysqli_prepare($conexion->conn, "INSERT INTO moviles (NOMBRE,MARCA,MODELO,RAM,PROCESADOR) VALUES (?,?,?,?,?)");
        $consulta->bind_param("sssss", $this->nombre, $this->marca, $this->modelo, $this->ram, $this->procesador);
        $consulta->execute();

        header('Location: app/Views/inventario.php');


    }
}
?>