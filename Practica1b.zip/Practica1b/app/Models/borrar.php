<?php

namespace inventario;

class borrar{
    public function eliminarRegistro($id){
        
        $conexion = new conexion();
        $consulta = mysqli_prepare($conexion->conn,"DELETE FROM moviles WHERE ID = ?");
        $consulta->bind_param("s",$id);
        $consulta->execute();
        
        header('Location: app/Views/inventario.php');
    }
}
?>