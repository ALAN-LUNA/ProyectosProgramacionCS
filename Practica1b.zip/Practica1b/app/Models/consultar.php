<?php

namespace inventario;

class existencia
{
    public function datos()
    {
        $conexion = new conexion();
        $consulta = "SELECT * FROM moviles";
        $resultado = mysqli_query($conexion->conn, $consulta);
        $row = mysqli_fetch_object($resultado);
        return $row;
    }
}
