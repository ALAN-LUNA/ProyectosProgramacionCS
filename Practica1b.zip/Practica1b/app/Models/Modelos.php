<?php

namespace inventario;

class Modelos
{

    public function mayores()
    {
        $conexion = new conexion();
        $consulta = "SELECT * FROM moviles";
        $resultado = mysqli_query($conexion->conn, $consulta);

        while ($row = mysqli_fetch_array($resultado)) {
            $consulta2 = "SELECT COUNT(MODELO) FROM moviles WHERE MARCA = '$row[2]' ";
            $resultado2 = mysqli_query($conexion->conn, $consulta2);
            $datos2 = mysqli_fetch_array($resultado2);


            if ($datos2[0] >= 10) {
                $_SESSION["masmodelos"] = $row[2];
            }
        }
    }
}
