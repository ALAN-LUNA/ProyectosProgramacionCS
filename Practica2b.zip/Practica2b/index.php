<?php
    if((!isset($_GET["controller"])) || (!isset($_GET["action"]))){
        echo "Peticion invalida";
        return false;
    }
    $controller = $_GET["controller"]."Controller";
    $action = $_GET["action"];

    require "./app/Controllers/$controller.php";
    $objeto = new $controller();
    $objeto ->{$action}();

?>