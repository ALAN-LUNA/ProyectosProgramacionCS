<?php
require "app/Models/conexion.php";
require "app/Models/consultabd.php";

use task\consulta;

class tareasController{

    function inicio(){
        $obj = new consulta();
        $obj->Tabla();
    }
    function crear()
    {
        $reg = new consulta();
        $reg->titulo = $_POST["titulo"];
        $reg->descripcion = $_POST["descripcion"];
        $reg->fecha = $_POST["fecha"];
        $reg->hora = $_POST["hora"];
        $reg->guardar();
    }
    function editar()
    {
        $act = new consulta();
        $act->titulo = $_POST["titulo_act"];
        $act->descripcion = $_POST["descripcion_act"];
        $act->fecha = $_POST["fecha_act"];
        $act->hora = $_POST["hora_act"];
        $act->obtener($_POST["id"]);
    }
    function borrar()
    {
        $del = new consulta();
        $del->eliminarRegistro($_POST["borrar_id"]);
    }
}
