<?php

namespace task;

class conexion{

    public $conn;

    public function __construct()
    {
        $host="localhost";
        $user="root";
        $contraseña="";
        $bd="base_tareas";
        $this->conn = mysqli_connect($host, $user, $contraseña, $bd);
    }

}
