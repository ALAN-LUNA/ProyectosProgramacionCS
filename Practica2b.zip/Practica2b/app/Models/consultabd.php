<?php

namespace task;

class consulta
{
    public $titulo;
    public $descripcion;
    public $fecha;
    public $hora;

    public function guardar()
    {
        $conexion = new conexion();
        $consulta = mysqli_prepare($conexion->conn, "INSERT INTO tareas (TITULO,DESCRIPCION,FECHA,HORA) VALUES (?,?,?,?)");
        $consulta->bind_param("ssss", $this->titulo, $this->descripcion, $this->fecha, $this->hora);
        $consulta->execute();

        header('Location: http://localhost/Practica2b/index.php?controller=tareas&action=inicio');
    }
    public function obtener($id)
    {
        $conexion = new conexion();
        $consulta = mysqli_prepare($conexion->conn, "UPDATE tareas SET TITULO = ?,DESCRIPCION = ?,FECHA = ?,HORA = ? WHERE ID = ?");
        $consulta->bind_param("sssss", $this->titulo, $this->descripcion, $this->fecha, $this->hora, $id);
        $consulta->execute();

        header('Location: http://localhost/Practica2b/index.php?controller=tareas&action=inicio');
    }
    public function eliminarRegistro($id)
    {

        $conexion = new conexion();
        $consulta = mysqli_prepare($conexion->conn, "DELETE FROM tareas WHERE ID = ?");
        $consulta->bind_param("s", $id);
        $consulta->execute();

        header('Location: http://localhost/Practica2b/index.php?controller=tareas&action=inicio');
    }
    public function Tabla()
    {
        $conexion = new conexion();
        $consulta = "SELECT * FROM tareas";
        $resultado = mysqli_query($conexion->conn, $consulta);
?>
        <form class="formulario" method="POST" action="http://localhost/Practica2b/index.php?controller=tareas&action=crear">
        
            <table>
                <tr>
                    <th>Titulo</th>
                    <th>Descripcion</th>
                    <th>Fecha</th>
                    <th>Hora</th>

                </tr>
                <tr>
                    <td>
                        <input type="text" name="titulo" placeholder="Titulo" required>
                    <td>
                        <input type="text" name="descripcion" placeholder="Descripcion" required>
                    </td>
                    <td>
                        <input type="date" name="fecha" value="<?php echo $_SESSION["hoy"] = date("Y - n - j");   ?>">
                    </td>
                    <td>
                        <input type="time" name="hora" required>
                    </td>
                    <td>
                    <input type="submit" value="Agregar nuevo">
                    </td>
                </tr>
            </table>
        </form>

        <table border="1px">
            <tr>
                <th>ID</th>
                <th>Titulo</th>
                <th>Descripcion</th>
                <th>Fecha</th>
                <th>Hora</th>
            </tr>

            <?php
            while ($row = mysqli_fetch_array($resultado)) { ?>
                <tr>
                    <td>
                        <?php echo $row[0]; ?>
                    </td>
                    <td>
                        <?php echo $row[1]; ?>
                    <td>
                        <?php echo $row[2]; ?>
                    </td>
                    <td >
                        <?php echo $row[3]; ?>
                    </td>
                    <td>
                        <?php echo $row[4]; ?>
                    </td>

                </tr>
            <?php
            }
            ?>
        </table>
        
        <h3>Eliminar por ID</h3>
        <form  method="POST" action="http://localhost/Practica2b/index.php?controller=tareas&action=borrar">
            <input type="number" size="3" name="borrar_id">
            <input type="submit" value="Borrar">
        </form>

        <h3>Editar por ID</h3>
        <form  method="POST" action="http://localhost/Practica2b/index.php?controller=tareas&action=editar">
            <input type="number" size="3" name="id">
            <input type="submit" value="Editar"><br>

            <table>
                <tr>
                    <th>Titulo</th>
                    <th>Descripcion</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                </tr>

                <tr>
                    <td>
                        <input type="text" name="titulo_act"  placeholder="Titulo" required>
                    <td>
                        <input type="text" name="descripcion_act"  placeholder="Descripcion" required>
                    </td>
                    <td>
                        <input type="date" name="fecha_act"  value="<?php echo date("Y - n - j");   ?>">
                    </td>
                    <td>
                        <input type="time" name="hora_act" value="12:30">
                    </td>
                </tr>
            </table>
        </form>
<?php
    }
}
?>